package dbdb;

import java.sql.SQLException;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.KeyAdapter;
import java.awt.event.KeyEvent;
import static dbdb.login_u.font;// ��Ʈ

@SuppressWarnings("serial")
public class register_u extends JFrame {
	boolean pwpwd_check = false;
	boolean idid_check = false;

	public register_u() {
		db_connection a = new db_connection(); // ���� ��ü ����
		setTitle("ȸ�� ���");
		setSize(455, 500);
		setLocationRelativeTo(null);
		setResizable(false);
		JPanel panel = new JPanel();
		panel.setLayout(new GridLayout(0, 1));

		JPanel id_panel = new JPanel();
		JLabel register_id = new JLabel("���̵�");
		register_id.setFont(font);
		JTextField reg_id = new JTextField(10); // id
		JButton user_check = new JButton("�ߺ�Ȯ��");
		user_check.setFont(font);
		id_panel.add(register_id);
		id_panel.add(reg_id);
		id_panel.add(user_check);

		JPanel pw_panel = new JPanel();
		JPanel pw_check_panel = new JPanel();
		JLabel pwd = new JLabel("��й�ȣ");
		pwd.setFont(font);
		JPasswordField pwpw = new JPasswordField(10); // pw
		JLabel pwd_ch = new JLabel("��й�ȣ Ȯ��");
		pwd_ch.setFont(font);
		JPasswordField pwpw_ch = new JPasswordField(10); // pw_check
		JButton pwd_check = new JButton("Ȯ��");
		pwd_check.setFont(font);
		pw_panel.add(pwd);
		pw_panel.add(pwpw);
		pw_check_panel.add(pwd_ch);
		pw_check_panel.add(pwpw_ch);
		pw_check_panel.add(pwd_check);

		JPanel user_nn = new JPanel();
		JLabel user_name = new JLabel("�̸�");
		user_name.setFont(font);
		JTextField user_na = new JTextField(10); // �̸�
		user_nn.add(user_name);
		user_nn.add(user_na);

		JPanel user_add = new JPanel();
		JLabel user_address = new JLabel("�ּ�");
		user_address.setFont(font);
		JTextField user_ad = new JTextField(10); // �ּ�
		user_add.add(user_address);
		user_add.add(user_ad);

		JPanel user_pho = new JPanel();
		JLabel user_phone = new JLabel("��ȭ��ȣ");
		user_phone.setFont(font);
		JTextField user_ph = new JTextField(10); // ��ȭ��ȣ
		user_pho.add(user_phone);
		user_pho.add(user_ph);

		JPanel user_acc = new JPanel();
		JLabel user_account = new JLabel("���¹�ȣ");
		JLabel line1 = new JLabel("-");
		JLabel line2 = new JLabel("-");
		JLabel line3 = new JLabel("-");
		user_account.setFont(font);
		JTextField user_ac1 = new JTextField(3); // ���¹�ȣ
		JTextField user_ac2 = new JTextField(3); // ���¹�ȣ
		JTextField user_ac3 = new JTextField(3); // ���¹�ȣ
		JTextField user_ac4 = new JTextField(3); // ���¹�ȣ
		user_acc.add(user_account);
		user_acc.add(user_ac1);
		user_acc.add(line1);
		user_acc.add(user_ac2);
		user_acc.add(line2);
		user_acc.add(user_ac3);
		user_acc.add(line3);
		user_acc.add(user_ac4);

		JPanel choose = new JPanel();
		JButton close = new JButton("�ݱ�");
		close.setFont(font);
		JButton register = new JButton("����ϱ�");
		register.setFont(font);
		choose.add(register);
		choose.add(close);

		user_check.addActionListener(new ActionListener() { // �ߺ�Ȯ��
			public void actionPerformed(ActionEvent e) {
				a.user_id_check(reg_id.getText());
				if (a.check) {
					JOptionPane.showMessageDialog(null, "��� ������ ���̵��Դϴ�.");
					idid_check = true;
				} else {
					idid_check = false;
				}
			}
		});

		// ���� ��ȣ�� 4���ھ�, ��ȭ��ȣ�� 11�� ���ڸ�, �̸��� ���ڸ�
		KeyAdapter eventHandler = new KeyAdapter() {
			@Override
			public void keyTyped(KeyEvent ke) {
				char c = ke.getKeyChar();

				if (((JTextField) ke.getSource()) == user_ph) { // ��ȭ��ȣ

					if (!Character.isDigit(c)) { // ���ڸ�
						ke.consume();
					}
					if (((JTextField) ke.getSource()).getText().length() >= 11) {
						ke.consume();
					}
				} else if (((JTextField) ke.getSource()) == user_na) {
					if (Character.isDigit(c)) { // ���ڸ�
						ke.consume();
					}
				} else { // �������� ���¹�ȣ
					if (!Character.isDigit(c)) { // ���ڸ�
						ke.consume();
					}
					if (((JTextField) ke.getSource()).getText().length() >= 4) {
						ke.consume();
					}
				}
			}
		};
		user_na.addKeyListener(eventHandler); // �� �ؽ�Ʈ�ʵ忡 �̺�Ʈ �߰�
		user_ph.addKeyListener(eventHandler);
		user_ac1.addKeyListener(eventHandler);
		user_ac2.addKeyListener(eventHandler);
		user_ac3.addKeyListener(eventHandler);
		user_ac4.addKeyListener(eventHandler);

		pwd_check.addActionListener(new ActionListener() { // ��й�ȣ Ȯ��
			public void actionPerformed(ActionEvent e) {
				@SuppressWarnings("deprecation")
				String pw = pwpw.getText();
				@SuppressWarnings("deprecation")
				String pwpw = pwpw_ch.getText();
				if (pwpw.equals(pw)) {
					JOptionPane.showMessageDialog(null, "equal");
					pwd_ch.setText("��й�ȣ Ȯ�� ��");
					pwpwd_check = true; // ��й�ȣ Ȯ�� üũ
				} else {
					JOptionPane.showMessageDialog(null, "not equal", "!", JOptionPane.WARNING_MESSAGE);
					pwpwd_check = false;
				}
			}
		});

		register.addActionListener(new ActionListener() { // ����ϱ�
			@SuppressWarnings("deprecation")
			public void actionPerformed(ActionEvent e) {
				// �ؽ�Ʈ�ʵ� ���� �Է¾ȵȰ� �ְų� �ߺ�Ȯ�� �� ��й�ȣ Ȯ�� ���ϸ� ����˸�â
				if (check_null(reg_id) && check_null(pwpw) && check_null(pwpw_ch) && check_null(user_na)
						&& check_null(user_ad) && check_null(user_ph) && check_null(user_ac1) && check_null(user_ac2)
						&& check_null(user_ac3) && check_null(user_ac4) && idid_check && pwpwd_check) {
					// ���� �ؽ�Ʈ �ʵ� ��ġ��
					String concat_field = user_ac1.getText() + "-" + user_ac2.getText() + "-" + user_ac3.getText() + "-"
							+ user_ac4.getText();
					// ȸ�� ��� �Լ��� �� ����
					a.user_register(reg_id.getText(), pwpw.getText(), user_na.getText(), user_ad.getText(),
							user_ph.getText(), concat_field);
					new login_u();
					dispose();
				} else {
					JOptionPane.showMessageDialog(null, "���ϰų� �������� \n������ Ȯ���ϼ���.", "!", JOptionPane.WARNING_MESSAGE);
				}
			}
		});
		close.addActionListener(new ActionListener() { // �ݱ�
			public void actionPerformed(ActionEvent e) {
				dispose();
			}
		});

		panel.add(id_panel);
		panel.add(pw_panel);
		panel.add(pw_check_panel);
		panel.add(user_nn);
		panel.add(user_add);
		panel.add(user_pho);
		panel.add(user_acc);
		add(panel, BorderLayout.CENTER);
		add(choose, BorderLayout.SOUTH);
		setVisible(true);
	}

	// �ؽ�Ʈ�ʵ尡 �ΰ����� Ȯ�� (���̸� true �ƴϸ� false�� !�� �ٲ���)
	public boolean check_null(JTextField content) {
		String a = content.getText();
		return !(a == null || a.isEmpty());
	}

	public static void main(String arg[]) throws SQLException {
		new register_u();
	}
}
